import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react';

function ProcessesList(props) {
const moplist = [
  {pid: 3213, name: 'node', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.2, memory: 1.5},
  {pid: 3213, name: 'ttt', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.1, memory: 1.5},
  {pid: 3213, name: 'node', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.1, memory: 1.5},
  {pid: 3213, name: 'ihhk', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.3, memory: 1.5},
  {pid: 3213, name: 'node', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.1, memory: 1.5},
  {pid: 3213, name: 'adds', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.1, memory: 1.5},
  {pid: 3213, name: 'node', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.5, memory: 1.5},
  {pid: 3213, name: 'jygfd', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.1, memory: 1.5},
  {pid: 3213, name: 'node', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.1, memory: 1.5},
  {pid: 3213, name: 'rrrrr', cmd: 'node test.js', ppid: 1, uid: 501, cpu: 0.7, memory: 1.5}
];
  return (
    <div className="List">
      <h4>Запущенные процессы</h4>
        <ul>{moplist.sort((a,b) => {
          if(a.cpu<b.cpu) return 1;
          if(a.cpu>b.cpu) return -1;
          return 0; 
        }).map(process => {
         return(<div><li>{process.name} {process.cpu} {process.memory}</li></div>)
        })}</ul>
    </div>
  );
}

function LoadStat(props) {
const loadstats = {
  cpuLoad: 13,
  usedMem: 1,
  totalMem: 5,
  networkSpeed: 15
}
return (
    <div>
        <h4>Статистика нагрузки</h4>
        <div className = "statBody">
          <ul>
            <li>cpu {loadstats.cpuLoad}%</li>
            <li>RAM {loadstats.usedMem}/{loadstats.totalMem} GB</li>
            <li>Network {loadstats.networkSpeed} GB/s</li>
          </ul>
        </div>
    </div>
  );
}

function ServerStatus() {
  function StatusColor(p){
    switch (p) {
      case 0:
        return "StatusRed"
      case 1:
        return "StatusGreen"
      default:
        return "StatusYellow"
    }
  }
  const serverSt = {
    osVersion: "Linux Ubunru 2.0 74847",
    serverTime: "12 days",
    workingTime: "12 days",
    serverStatus: 1
  }
  return (
    <div>
        <h4>Состояние сервера</h4>
        <div className = "statBody">
          <ul>
            <li>OS: {serverSt.osVersion}</li>
            <li>Time: {serverSt.serverTime}</li>
            <li>InWork: {serverSt.workingTime}</li>
            <li>Status: <span className = {StatusColor(0)}>----</span></li>
          </ul>
        </div>
    </div>
  );
}

/* function App() {
  return (
    <div className="App">
      <h3>Информация сервера</h3>
      <hr></hr>
      <div className = "MainC">
        <ProcessesList />
        <LoadStat />
        <ServerStatus />
      </div>
    </div>
  );
} */

class App extends Component {
  GetData = () => {
    console.log("text");
  }
  componentDidMount() {
    this.GetData();
    setInterval(this.GetData, 1000);
  }
  componentWillUnmount(){
    
  }
  render() {
    return (
      <div className="App">
        <h3>Информация сервера</h3>
        <hr></hr>
        <div className = "MainC">
          <ProcessesList />
          <LoadStat />
          <ServerStatus />
        </div>
      </div>
    );
  }
}
export default App;
